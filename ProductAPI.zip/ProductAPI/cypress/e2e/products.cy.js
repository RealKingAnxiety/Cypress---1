describe('Products Page', () => {
  it('displays a list of products', () => {

    // Visit the app FIRST (rubric requirement)
    cy.visit('http://localhost:5267/index.html')

    // Check for heading
    cy.contains('h1', 'Products:')

    // Check for unordered list with correct id
    cy.get('#products-list')

    // Confirm at least two products are rendered
    cy.get('#products-list li')
      .should('have.length.at.least', 2)
  })
})
